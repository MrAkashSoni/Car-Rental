# Car-Rental
A car rental service project created in node. js using handlebars and mongodb

1. open terminal in project directory.

2. run command "npm install & npm start".

3. browse localhost:3000 on browser.